<?php
/**
 * IdentiPet — Crear usuario administrador (script de un solo uso)
 * ---------------------------------------------------------------------------
 * USO:
 *   - Por navegador:  https://identipet.pe/database/create_admin.php
 *     (ajusta los valores de abajo ANTES de subirlo, o pásalos por GET).
 *   - Por consola SSH: php database/create_admin.php "Nombre" "Apellido" "email" "password"
 *
 *  IMPORTANTE: BORRA este archivo del servidor después de usarlo.
 * ---------------------------------------------------------------------------
 */

declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
define('STORAGE_PATH', BASE_PATH . '/storage');
$config = require BASE_PATH . '/config/config.php';

// --- Datos del administrador (edítalos o pásalos por argumentos/GET) ---
$nombre   = $argv[1] ?? ($_GET['nombre']   ?? 'Renzo');
$apellido = $argv[2] ?? ($_GET['apellido'] ?? 'Madrid');
$email    = $argv[3] ?? ($_GET['email']    ?? 'admin@identipet.pe');
$password = $argv[4] ?? ($_GET['password'] ?? '');

if ($password === '') {
    exit("Define una contraseña. Ej (consola): php database/create_admin.php \"Renzo\" \"Madrid\" \"admin@identipet.pe\" \"TuClaveSegura\"\n");
}

try {
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $config['db']['host'], $config['db']['port'] ?? 3306,
        $config['db']['database'], $config['db']['charset'] ?? 'utf8mb4');
    $pdo = new PDO($dsn, $config['db']['username'], $config['db']['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // ¿Ya existe?
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([strtolower($email)]);
    if ($stmt->fetch()) {
        exit("Ya existe un usuario con el email {$email}.\n");
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $sql = 'INSERT INTO users
              (role_id, nombre, apellido, email, password_hash, status, email_verified_at, created_at, updated_at)
            VALUES (1, ?, ?, ?, ?, "active", NOW(), NOW(), NOW())';
    $pdo->prepare($sql)->execute([$nombre, $apellido, strtolower($email), $hash]);

    echo "Administrador creado correctamente: {$email}\n";
    echo "RECUERDA: borra este archivo (database/create_admin.php) del servidor.\n";
} catch (Throwable $e) {
    echo 'Error: ' . $e->getMessage() . "\n";
}

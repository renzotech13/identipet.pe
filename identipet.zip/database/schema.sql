-- =========================================================================
--  IdentiPet — Esquema de base de datos (MVP)
--  Motor: MySQL 5.7+ / MariaDB 10.3+  (SiteGround)
--  Codificación: utf8mb4
--
--  Cómo importar en SiteGround:
--    1. Crea una base de datos y un usuario desde Site Tools > MySQL.
--    2. Abre phpMyAdmin y selecciona tu base de datos.
--    3. Pestaña "Importar" > sube este archivo schema.sql > Continuar.
--
--  Diseñado para crecer hacia el ecosistema completo (marketplace, empresas,
--  reservas, etc.) sin rehacer la arquitectura.
-- =========================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- -------------------------------------------------------------------------
--  ROLES
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
    id          TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name        VARCHAR(50)  NOT NULL,
    label       VARCHAR(80)  NOT NULL,
    created_at  TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_roles_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO roles (id, name, label) VALUES
    (1, 'administrador', 'Administrador'),
    (2, 'propietario',   'Propietario'),
    (3, 'veterinario',   'Veterinario'),
    (4, 'empresa',       'Empresa Aliada')
ON DUPLICATE KEY UPDATE label = VALUES(label);

-- -------------------------------------------------------------------------
--  USUARIOS
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    role_id            TINYINT UNSIGNED NOT NULL DEFAULT 2,
    nombre             VARCHAR(100) NOT NULL,
    apellido           VARCHAR(100) NOT NULL,
    email              VARCHAR(160) NOT NULL,
    celular            VARCHAR(30)  NULL,
    password_hash      VARCHAR(255) NOT NULL,
    direccion          VARCHAR(200) NULL,
    distrito           VARCHAR(100) NULL,
    ciudad             VARCHAR(100) NULL,
    fecha_nacimiento   DATE         NULL,
    avatar             VARCHAR(255) NULL,
    status             ENUM('pending','active','suspended') NOT NULL DEFAULT 'pending',
    email_verified_at  TIMESTAMP    NULL,
    activation_token   VARCHAR(80)  NULL,
    remember_token     VARCHAR(80)  NULL,
    last_login_at      TIMESTAMP    NULL,
    created_at         TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role (role_id),
    KEY idx_users_status (status),
    CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  RECUPERACIÓN DE CONTRASEÑA
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS password_resets (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email       VARCHAR(160) NOT NULL,
    token       VARCHAR(80)  NOT NULL,
    created_at  TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pr_email (email),
    KEY idx_pr_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  MASCOTAS
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pets (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_id            BIGINT UNSIGNED NOT NULL,
    identipet_code      VARCHAR(20)  NOT NULL,           -- Número único IdentiPet
    slug_publico        VARCHAR(60)  NOT NULL,           -- para la página pública/QR
    codigo_interno      VARCHAR(40)  NULL,
    foto                VARCHAR(255) NULL,
    qr_path             VARCHAR(255) NULL,
    nombre              VARCHAR(80)  NOT NULL,
    especie             VARCHAR(40)  NOT NULL DEFAULT 'Perro',
    raza                VARCHAR(80)  NULL,
    sexo                ENUM('macho','hembra','desconocido') NOT NULL DEFAULT 'desconocido',
    fecha_nacimiento    DATE         NULL,
    color               VARCHAR(60)  NULL,
    peso                DECIMAL(6,2) NULL,                -- kg
    tiene_microchip     TINYINT(1)   NOT NULL DEFAULT 0,
    numero_chip         VARCHAR(40)  NULL,
    caracteristicas     TEXT         NULL,
    estado_reproductivo ENUM('entero','castrado','esterilizado','desconocido') NOT NULL DEFAULT 'desconocido',
    vet_id              BIGINT UNSIGNED NULL,             -- veterinario de cabecera
    perdido             TINYINT(1)   NOT NULL DEFAULT 0,
    perdido_desde       TIMESTAMP    NULL,
    recompensa          VARCHAR(120) NULL,
    estado              ENUM('activa','inactiva','fallecida') NOT NULL DEFAULT 'activa',
    created_at          TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_pets_code (identipet_code),
    UNIQUE KEY uq_pets_slug (slug_publico),
    KEY idx_pets_owner (owner_id),
    KEY idx_pets_vet (vet_id),
    KEY idx_pets_perdido (perdido),
    CONSTRAINT fk_pets_owner FOREIGN KEY (owner_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_pets_vet   FOREIGN KEY (vet_id)   REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  ACCESO COMPARTIDO (perfil familiar: varios propietarios por mascota)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pet_shared_access (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pet_id      BIGINT UNSIGNED NOT NULL,
    user_id     BIGINT UNSIGNED NOT NULL,
    rol         ENUM('co-propietario','familiar','cuidador') NOT NULL DEFAULT 'familiar',
    puede_editar TINYINT(1)     NOT NULL DEFAULT 0,
    created_at  TIMESTAMP       NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_share (pet_id, user_id),
    CONSTRAINT fk_share_pet  FOREIGN KEY (pet_id)  REFERENCES pets (id)  ON DELETE CASCADE,
    CONSTRAINT fk_share_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  CONTACTOS DE EMERGENCIA
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pet_contacts (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pet_id      BIGINT UNSIGNED NOT NULL,
    nombre      VARCHAR(100) NOT NULL,
    telefono    VARCHAR(30)  NOT NULL,
    relacion    VARCHAR(60)  NULL,
    es_principal TINYINT(1)  NOT NULL DEFAULT 0,
    created_at  TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_contacts_pet (pet_id),
    CONSTRAINT fk_contacts_pet FOREIGN KEY (pet_id) REFERENCES pets (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  HISTORIAL MÉDICO (consultas, cirugías, desparasitaciones, etc.)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS medical_records (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pet_id      BIGINT UNSIGNED NOT NULL,
    vet_id      BIGINT UNSIGNED NULL,
    tipo        ENUM('consulta','desparasitacion','cirugia','hospitalizacion',
                     'medicamento','alergia','peso','radiografia','ecografia',
                     'laboratorio','observacion','otro') NOT NULL DEFAULT 'consulta',
    titulo      VARCHAR(160) NOT NULL,
    descripcion TEXT         NULL,
    peso        DECIMAL(6,2) NULL,
    archivo     VARCHAR(255) NULL,
    fecha       DATE         NOT NULL,
    created_at  TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_med_pet (pet_id),
    KEY idx_med_vet (vet_id),
    KEY idx_med_tipo (tipo),
    CONSTRAINT fk_med_pet FOREIGN KEY (pet_id) REFERENCES pets (id)  ON DELETE CASCADE,
    CONSTRAINT fk_med_vet FOREIGN KEY (vet_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  VACUNAS (separadas para gestionar próxima dosis y recordatorios)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vaccines (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pet_id          BIGINT UNSIGNED NOT NULL,
    vet_id          BIGINT UNSIGNED NULL,
    nombre          VARCHAR(120) NOT NULL,           -- ej. Antirrábica, Quíntuple
    lote            VARCHAR(60)  NULL,
    fecha_aplicada  DATE         NOT NULL,
    proxima_dosis   DATE         NULL,
    archivo         VARCHAR(255) NULL,
    created_at      TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_vac_pet (pet_id),
    KEY idx_vac_proxima (proxima_dosis),
    CONSTRAINT fk_vac_pet FOREIGN KEY (pet_id) REFERENCES pets (id)  ON DELETE CASCADE,
    CONSTRAINT fk_vac_vet FOREIGN KEY (vet_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  GESTOR DOCUMENTAL
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pet_id      BIGINT UNSIGNED NOT NULL,
    user_id     BIGINT UNSIGNED NULL,                -- quién lo subió
    carpeta     VARCHAR(80)  NOT NULL DEFAULT 'General',
    tipo        ENUM('pdf','imagen','video','radiografia','receta','boleta',
                     'contrato','certificado','otro') NOT NULL DEFAULT 'otro',
    nombre      VARCHAR(160) NOT NULL,
    ruta        VARCHAR(255) NOT NULL,
    mime        VARCHAR(100) NULL,
    tamano      INT UNSIGNED NULL,                   -- bytes
    created_at  TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_doc_pet (pet_id),
    KEY idx_doc_carpeta (carpeta),
    CONSTRAINT fk_doc_pet  FOREIGN KEY (pet_id)  REFERENCES pets (id)  ON DELETE CASCADE,
    CONSTRAINT fk_doc_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  RECORDATORIOS
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reminders (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pet_id      BIGINT UNSIGNED NOT NULL,
    user_id     BIGINT UNSIGNED NOT NULL,
    tipo        ENUM('vacuna','desparasitacion','medicamento','bano','peluqueria',
                     'control','cumpleanos','otro') NOT NULL DEFAULT 'otro',
    titulo      VARCHAR(160) NOT NULL,
    nota        VARCHAR(255) NULL,
    fecha       DATETIME     NOT NULL,
    canal       SET('correo','whatsapp','push','sms') NOT NULL DEFAULT 'correo',
    enviado     TINYINT(1)   NOT NULL DEFAULT 0,
    completado  TINYINT(1)   NOT NULL DEFAULT 0,
    created_at  TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_rem_pet (pet_id),
    KEY idx_rem_fecha (fecha),
    KEY idx_rem_enviado (enviado),
    CONSTRAINT fk_rem_pet  FOREIGN KEY (pet_id)  REFERENCES pets (id)  ON DELETE CASCADE,
    CONSTRAINT fk_rem_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
--  CONFIGURACIÓN GENERAL (clave/valor)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    clave       VARCHAR(80)  NOT NULL,
    valor       TEXT         NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_settings_clave (clave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO settings (clave, valor) VALUES
    ('site_name', 'IdentiPet'),
    ('site_phone', ''),
    ('site_email', 'contacto@identipet.pe'),
    ('codigo_prefix', 'IP')
ON DUPLICATE KEY UPDATE valor = valor;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================================================================
--  FIN DEL ESQUEMA MVP
--  El usuario administrador se crea con database/create_admin.php (una vez).
-- =========================================================================

<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;

/**
 * Controlador de autenticación.
 * Por ahora solo muestra los formularios (módulo de lógica en el siguiente paso).
 */
class AuthController extends Controller
{
    public function showLogin(array $params = []): void
    {
        $this->view('auth/login', [
            'title' => 'Iniciar sesión — IdentiPet',
        ], 'auth');
    }

    public function showRegister(array $params = []): void
    {
        $this->view('auth/register', [
            'title' => 'Crear cuenta — IdentiPet',
        ], 'auth');
    }

    // Próximo módulo:
    // public function login(array $params = []): void {}
    // public function register(array $params = []): void {}
    // public function logout(array $params = []): void {}
    // public function activate(array $params = []): void {}
}

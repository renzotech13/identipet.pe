<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;

class HomeController extends Controller
{
    public function index(array $params = []): void
    {
        // Estadísticas (placeholder; se conectarán a datos reales por módulo)
        $stats = [
            'mascotas'     => 0,
            'veterinarias' => 0,
            'empresas'     => 0,
            'usuarios'     => 0,
        ];

        $this->view('home/index', [
            'title' => 'IdentiPet — La identidad digital de tu mascota',
            'stats' => $stats,
        ]);
    }

    public function comoFunciona(array $params = []): void
    {
        $this->view('home/como-funciona', [
            'title' => 'Cómo funciona — IdentiPet',
        ]);
    }

    public function beneficios(array $params = []): void
    {
        $this->view('home/beneficios', [
            'title' => 'Beneficios — IdentiPet',
        ]);
    }

    public function contacto(array $params = []): void
    {
        $this->view('home/contacto', [
            'title' => 'Contacto — IdentiPet',
        ]);
    }

    /** Verificación de salud del sistema y conexión a base de datos. */
    public function health(array $params = []): void
    {
        $db = 'desconocido';
        try {
            Database::getInstance()->first('SELECT 1');
            $db = 'ok';
        } catch (\Throwable $e) {
            $db = 'error';
        }

        $this->json([
            'app'       => 'IdentiPet',
            'status'    => 'online',
            'database'  => $db,
            'php'       => PHP_VERSION,
            'timestamp' => date('c'),
        ]);
    }
}

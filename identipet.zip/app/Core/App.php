<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Kernel de la aplicación: inicializa servicios y despacha la petición.
 */
class App
{
    private array $config;
    private Router $router;

    public function __construct(array $config)
    {
        $this->config = $config;

        // Zona horaria y locale
        date_default_timezone_set($config['app']['timezone'] ?? 'America/Lima');

        // Inicializar base de datos
        Database::init($config['db']);

        // Sesión
        Session::start($config['session'] ?? []);

        // Router y rutas
        $this->router = new Router();
        $this->registerRoutes();

        // Datos compartidos con todas las vistas
        View::share('config', $config);
        View::share('authUser', Auth::user());
        View::share('csrf', Csrf::token());
    }

    private function registerRoutes(): void
    {
        $router = $this->router;
        require BASE_PATH . '/config/routes.php';
    }

    public function run(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $uri    = $_SERVER['REQUEST_URI'] ?? '/';

        // Soporte de _method para formularios (PUT/DELETE)
        if ($method === 'POST' && isset($_POST['_method'])) {
            $override = strtoupper($_POST['_method']);
            if (in_array($override, ['PUT', 'DELETE'], true)) {
                $method = $override;
            }
        }

        $match = $this->router->match($method, $uri);

        if ($match === null) {
            $this->notFound();
            return;
        }

        $controllerClass = 'App\\Controllers\\' . $match['route']['controller'];
        $action          = $match['route']['action'];

        if (!class_exists($controllerClass) || !method_exists($controllerClass, $action)) {
            $this->notFound();
            return;
        }

        $controller = new $controllerClass();
        $controller->$action($match['params']);
    }

    private function notFound(): void
    {
        http_response_code(404);
        View::render('errors/404', [], 'app');
    }
}

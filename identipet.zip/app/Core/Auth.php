<?php

declare(strict_types=1);

namespace App\Core;

use App\Models\User;

/**
 * Autenticación de usuarios basada en sesión.
 * Roles soportados: propietario, veterinario, empresa, administrador.
 */
class Auth
{
    private const SESSION_KEY = 'auth_user_id';

    /** Intenta iniciar sesión con email + contraseña. */
    public static function attempt(string $email, string $password): bool
    {
        $user = User::findByEmail($email);
        if ($user === null) {
            return false;
        }
        if (!password_verify($password, $user['password_hash'])) {
            return false;
        }
        if (($user['status'] ?? '') !== 'active') {
            return false; // cuenta no activada o suspendida
        }
        self::login((int) $user['id']);
        return true;
    }

    public static function login(int $userId): void
    {
        session_regenerate_id(true);
        Session::set(self::SESSION_KEY, $userId);
    }

    public static function logout(): void
    {
        Session::forget(self::SESSION_KEY);
        session_regenerate_id(true);
    }

    public static function check(): bool
    {
        return Session::has(self::SESSION_KEY);
    }

    public static function id(): ?int
    {
        $id = Session::get(self::SESSION_KEY);
        return $id !== null ? (int) $id : null;
    }

    /** Devuelve el registro del usuario autenticado (con caché en memoria). */
    public static function user(): ?array
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }
        $id = self::id();
        if ($id === null) {
            return null;
        }
        $cached = User::find($id);
        return $cached;
    }

    public static function role(): ?string
    {
        $user = self::user();
        return $user['role'] ?? null;
    }

    public static function hasRole(string ...$roles): bool
    {
        $role = self::role();
        return $role !== null && in_array($role, $roles, true);
    }
}

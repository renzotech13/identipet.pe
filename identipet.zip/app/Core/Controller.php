<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Controlador base. Provee helpers comunes a todos los controladores.
 */
abstract class Controller
{
    /** Renderiza una vista con layout. */
    protected function view(string $view, array $data = [], string $layout = 'app'): void
    {
        View::render($view, $data, $layout);
    }

    /** Devuelve JSON. */
    protected function json($data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /** Redirección. */
    protected function redirect(string $path): void
    {
        if (!preg_match('#^https?://#', $path)) {
            $path = '/' . ltrim($path, '/');
        }
        header('Location: ' . $path);
        exit;
    }

    /** Redirige a la página anterior (o a un fallback). */
    protected function back(string $fallback = '/'): void
    {
        $ref = $_SERVER['HTTP_REFERER'] ?? $fallback;
        $this->redirect($ref);
    }

    /** Obtiene un valor de entrada (POST/GET) con valor por defecto. */
    protected function input(string $key, $default = null)
    {
        return $_POST[$key] ?? $_GET[$key] ?? $default;
    }

    /** Exige que el usuario esté autenticado; si no, redirige al login. */
    protected function requireAuth(): void
    {
        if (!Auth::check()) {
            Session::flash('error', 'Debes iniciar sesión para continuar.');
            $this->redirect('/login');
        }
    }

    /** Exige uno o más roles; si no, error 403. */
    protected function requireRole(string ...$roles): void
    {
        $this->requireAuth();
        if (!Auth::hasRole(...$roles)) {
            http_response_code(403);
            View::render('errors/403', [], 'app');
            exit;
        }
    }

    /** Valida el token CSRF (usar al inicio de acciones POST). */
    protected function verifyCsrf(): void
    {
        Csrf::check();
    }
}

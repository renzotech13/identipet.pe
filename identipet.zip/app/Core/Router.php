<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Enrutador simple con soporte de parámetros dinámicos.
 * Ejemplo de ruta: '/mascota/{slug}' -> ['PetController', 'show']
 */
class Router
{
    /** @var array<string, array<string, array{controller:string, action:string, middleware:array}>> */
    private array $routes = [
        'GET'    => [],
        'POST'   => [],
        'PUT'    => [],
        'DELETE' => [],
    ];

    public function get(string $path, string $controller, string $action, array $middleware = []): void
    {
        $this->add('GET', $path, $controller, $action, $middleware);
    }

    public function post(string $path, string $controller, string $action, array $middleware = []): void
    {
        $this->add('POST', $path, $controller, $action, $middleware);
    }

    public function put(string $path, string $controller, string $action, array $middleware = []): void
    {
        $this->add('PUT', $path, $controller, $action, $middleware);
    }

    public function delete(string $path, string $controller, string $action, array $middleware = []): void
    {
        $this->add('DELETE', $path, $controller, $action, $middleware);
    }

    private function add(string $method, string $path, string $controller, string $action, array $middleware): void
    {
        $path = '/' . trim($path, '/');
        $this->routes[$method][$path] = [
            'controller' => $controller,
            'action'     => $action,
            'middleware' => $middleware,
        ];
    }

    /**
     * Resuelve la URI actual y devuelve la ruta + parámetros, o null si no existe.
     * @return array{route:array, params:array}|null
     */
    public function match(string $method, string $uri): ?array
    {
        // Normalizar URI (quitar querystring y barra final)
        $uri = parse_url($uri, PHP_URL_PATH) ?: '/';
        $uri = '/' . trim(rawurldecode($uri), '/');
        if ($uri === '/') {
            $uri = '/';
        }

        // Soportar method override para PUT/DELETE desde formularios
        $routes = $this->routes[$method] ?? [];

        foreach ($routes as $routePath => $route) {
            $params = $this->matchPath($routePath, $uri);
            if ($params !== null) {
                return ['route' => $route, 'params' => $params];
            }
        }

        return null;
    }

    /**
     * Compara una ruta con parámetros {x} contra la URI.
     * @return array<string,string>|null
     */
    private function matchPath(string $routePath, string $uri): ?array
    {
        if ($routePath === $uri) {
            return [];
        }

        if (strpos($routePath, '{') === false) {
            return null;
        }

        $pattern = preg_replace('#\{([a-zA-Z_][a-zA-Z0-9_]*)\}#', '(?P<$1>[^/]+)', $routePath);
        $pattern = '#^' . $pattern . '$#';

        if (preg_match($pattern, $uri, $matches)) {
            $params = [];
            foreach ($matches as $key => $value) {
                if (!is_int($key)) {
                    $params[$key] = $value;
                }
            }
            return $params;
        }

        return null;
    }
}

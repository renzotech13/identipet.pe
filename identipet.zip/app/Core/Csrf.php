<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Protección CSRF: genera y valida tokens para formularios POST.
 */
class Csrf
{
    private const KEY = '_csrf_token';

    public static function token(): string
    {
        if (empty($_SESSION[self::KEY])) {
            $_SESSION[self::KEY] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::KEY];
    }

    /** Campo oculto listo para insertar en formularios. */
    public static function field(): string
    {
        return '<input type="hidden" name="' . self::KEY . '" value="' . self::token() . '">';
    }

    public static function validate(?string $token): bool
    {
        $stored = $_SESSION[self::KEY] ?? '';
        return is_string($token) && $stored !== '' && hash_equals($stored, $token);
    }

    /** Lanza error 419 si el token no es válido (para peticiones POST/PUT/DELETE). */
    public static function check(): void
    {
        $token = $_POST[self::KEY] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);
        if (!self::validate($token)) {
            http_response_code(419);
            exit('Token de seguridad inválido o expirado. Recarga la página e inténtalo de nuevo.');
        }
    }
}

<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Motor de vistas mínimo basado en PHP plano + layouts.
 * Las vistas viven en app/Views. El layout envuelve el contenido.
 */
class View
{
    private static array $shared = [];

    /** Comparte datos disponibles en todas las vistas (ej. usuario actual). */
    public static function share(string $key, $value): void
    {
        self::$shared[$key] = $value;
    }

    /**
     * Renderiza una vista dentro de un layout.
     *
     * @param string $view   ruta relativa sin extensión, ej. 'home/index'
     * @param array  $data   variables para la vista
     * @param string $layout layout en Views/layouts, ej. 'app' o 'auth'
     */
    public static function render(string $view, array $data = [], string $layout = 'app'): void
    {
        $data = array_merge(self::$shared, $data);

        $viewFile = APP_PATH . '/Views/' . $view . '.php';
        if (!is_file($viewFile)) {
            throw new \RuntimeException("Vista no encontrada: {$view}");
        }

        // Capturar el contenido de la vista
        extract($data, EXTR_SKIP);
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        // Si no hay layout, devolver solo el contenido
        if ($layout === '') {
            echo $content;
            return;
        }

        $layoutFile = APP_PATH . '/Views/layouts/' . $layout . '.php';
        if (!is_file($layoutFile)) {
            throw new \RuntimeException("Layout no encontrado: {$layout}");
        }
        require $layoutFile;
    }

    /** Renderiza una vista parcial (sin layout) y la devuelve como string. */
    public static function partial(string $view, array $data = []): string
    {
        $data = array_merge(self::$shared, $data);
        $viewFile = APP_PATH . '/Views/' . $view . '.php';
        if (!is_file($viewFile)) {
            return '';
        }
        extract($data, EXTR_SKIP);
        ob_start();
        require $viewFile;
        return ob_get_clean();
    }

    /** Escape seguro para HTML. */
    public static function e($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

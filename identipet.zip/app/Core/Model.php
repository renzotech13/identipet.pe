<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Modelo base. Provee acceso rápido a la base de datos a los modelos hijos.
 */
abstract class Model
{
    /** Nombre de la tabla (lo define cada modelo hijo). */
    protected static string $table = '';

    protected static function db(): Database
    {
        return Database::getInstance();
    }

    /** Busca un registro por su clave primaria. */
    public static function find(int $id): ?array
    {
        return static::db()->first(
            'SELECT * FROM ' . static::$table . ' WHERE id = :id LIMIT 1',
            ['id' => $id]
        );
    }

    /** Devuelve todos los registros (con límite opcional). */
    public static function allRecords(int $limit = 100, int $offset = 0): array
    {
        return static::db()->all(
            'SELECT * FROM ' . static::$table . ' ORDER BY id DESC LIMIT :lim OFFSET :off',
            ['lim' => $limit, 'off' => $offset]
        );
    }

    /** Cuenta total de registros. */
    public static function count(): int
    {
        $row = static::db()->first('SELECT COUNT(*) AS c FROM ' . static::$table);
        return (int) ($row['c'] ?? 0);
    }

    /** Elimina por id. */
    public static function destroy(int $id): bool
    {
        return static::db()->execute(
            'DELETE FROM ' . static::$table . ' WHERE id = :id',
            ['id' => $id]
        ) > 0;
    }
}

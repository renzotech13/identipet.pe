<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use PDOStatement;

/**
 * Capa de acceso a datos basada en PDO (MySQL).
 * Singleton: una sola conexión por petición.
 */
class Database
{
    private static ?Database $instance = null;
    private PDO $pdo;

    private function __construct(array $config)
    {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $config['host'],
            (int) ($config['port'] ?? 3306),
            $config['database'],
            $config['charset'] ?? 'utf8mb4'
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $this->pdo = new PDO($dsn, $config['username'], $config['password'], $options);
        } catch (PDOException $e) {
            // No exponer credenciales; registrar y mostrar mensaje genérico.
            error_log('[IdentiPet][DB] ' . $e->getMessage());
            http_response_code(500);
            exit('Error de conexión con la base de datos. Revisa la configuración.');
        }
    }

    /** Inicializa (una vez) la conexión con la configuración dada. */
    public static function init(array $config): void
    {
        if (self::$instance === null) {
            self::$instance = new self($config);
        }
    }

    /** Devuelve la instancia única. */
    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            throw new \RuntimeException('Database no inicializada. Llama a Database::init() primero.');
        }
        return self::$instance;
    }

    /** Acceso directo al objeto PDO si se necesita. */
    public function pdo(): PDO
    {
        return $this->pdo;
    }

    /** Ejecuta una consulta con parámetros y devuelve el statement. */
    public function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /** Devuelve una sola fila (o null). */
    public function first(string $sql, array $params = []): ?array
    {
        $row = $this->query($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    /** Devuelve todas las filas. */
    public function all(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)->fetchAll();
    }

    /** Ejecuta un INSERT/UPDATE/DELETE y devuelve filas afectadas. */
    public function execute(string $sql, array $params = []): int
    {
        return $this->query($sql, $params)->rowCount();
    }

    /** ID del último registro insertado. */
    public function lastInsertId(): string
    {
        return $this->pdo->lastInsertId();
    }

    public function beginTransaction(): bool
    {
        return $this->pdo->beginTransaction();
    }

    public function commit(): bool
    {
        return $this->pdo->commit();
    }

    public function rollBack(): bool
    {
        return $this->pdo->rollBack();
    }
}

<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

/**
 * Modelo de Usuario.
 * El campo "role" se resuelve por join con la tabla roles.
 */
class User extends Model
{
    protected static string $table = 'users';

    /** Busca por id incluyendo el nombre del rol. */
    public static function find(int $id): ?array
    {
        return static::db()->first(
            'SELECT u.*, r.name AS role
               FROM users u
               JOIN roles r ON r.id = u.role_id
              WHERE u.id = :id
              LIMIT 1',
            ['id' => $id]
        );
    }

    /** Busca por email incluyendo el nombre del rol. */
    public static function findByEmail(string $email): ?array
    {
        return static::db()->first(
            'SELECT u.*, r.name AS role
               FROM users u
               JOIN roles r ON r.id = u.role_id
              WHERE u.email = :email
              LIMIT 1',
            ['email' => strtolower(trim($email))]
        );
    }

    public static function emailExists(string $email): bool
    {
        $row = static::db()->first(
            'SELECT id FROM users WHERE email = :email LIMIT 1',
            ['email' => strtolower(trim($email))]
        );
        return $row !== null;
    }

    /**
     * Crea un usuario. Devuelve el id insertado.
     * $data debe incluir: role_id, nombre, apellido, email, celular,
     * password (texto plano), direccion, distrito, ciudad, fecha_nacimiento.
     */
    public static function create(array $data): int
    {
        $sql = 'INSERT INTO users
                  (role_id, nombre, apellido, email, celular, password_hash,
                   direccion, distrito, ciudad, fecha_nacimiento,
                   activation_token, status, created_at, updated_at)
                VALUES
                  (:role_id, :nombre, :apellido, :email, :celular, :password_hash,
                   :direccion, :distrito, :ciudad, :fecha_nacimiento,
                   :activation_token, :status, NOW(), NOW())';

        static::db()->execute($sql, [
            'role_id'          => $data['role_id'],
            'nombre'           => $data['nombre'],
            'apellido'         => $data['apellido'],
            'email'            => strtolower(trim($data['email'])),
            'celular'          => $data['celular'] ?? null,
            'password_hash'    => password_hash($data['password'], PASSWORD_DEFAULT),
            'direccion'        => $data['direccion'] ?? null,
            'distrito'         => $data['distrito'] ?? null,
            'ciudad'           => $data['ciudad'] ?? null,
            'fecha_nacimiento' => $data['fecha_nacimiento'] ?? null,
            'activation_token' => $data['activation_token'] ?? null,
            'status'           => $data['status'] ?? 'pending',
        ]);

        return (int) static::db()->lastInsertId();
    }

    /** Activa la cuenta a partir del token de activación. */
    public static function activateByToken(string $token): bool
    {
        return static::db()->execute(
            "UPDATE users
                SET status = 'active', email_verified_at = NOW(),
                    activation_token = NULL, updated_at = NOW()
              WHERE activation_token = :token AND status = 'pending'",
            ['token' => $token]
        ) > 0;
    }
}

<?php
/** @var string $content  Contenido de la vista (inyectado por View::render) */
/** @var array  $config */
/** @var array|null $authUser */
use App\Core\View;
use App\Core\Session;

$title = $title ?? 'IdentiPet';
$appUrl = $config['app']['url'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= View::e($title) ?></title>
    <meta name="description" content="IdentiPet — La identidad digital de tu mascota. Registro, historial médico, carnet digital, QR y beneficios en una sola plataforma.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="icon" href="/assets/img/favicon.png">
</head>
<body>

<header class="site-header">
    <div class="container navbar">
        <a href="/" class="brand">
            <span class="logo-dot">🐾</span>
            <span>Identi<span class="brand-pet">Pet</span></span>
        </a>

        <ul class="nav-links" id="navLinks">
            <li><a href="/#como-funciona">Cómo funciona</a></li>
            <li><a href="/#beneficios">Beneficios</a></li>
            <li><a href="/#marketplace">Marketplace</a></li>
            <li><a href="/#veterinarias">Veterinarias</a></li>
            <li><a href="/#blog">Blog</a></li>
        </ul>

        <div class="nav-actions">
            <?php if (!empty($authUser)): ?>
                <a href="/panel" class="btn btn-outline">Mi panel</a>
                <a href="/logout" class="btn btn-primary">Salir</a>
            <?php else: ?>
                <a href="/login" class="btn btn-outline">Ingresar</a>
                <a href="/registro" class="btn btn-primary">Registrar mascota</a>
            <?php endif; ?>
        </div>

        <button class="nav-toggle" onclick="document.getElementById('navLinks').classList.toggle('open')">☰</button>
    </div>
</header>

<?php if ($msg = Session::flash('success')): ?>
    <div class="container mt-2"><div class="alert alert-success"><?= View::e($msg) ?></div></div>
<?php endif; ?>
<?php if ($msg = Session::flash('error')): ?>
    <div class="container mt-2"><div class="alert alert-error"><?= View::e($msg) ?></div></div>
<?php endif; ?>

<main>
    <?= $content ?>
</main>

<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <div class="footer-brand">Identi<span style="color:var(--color-primary)">Pet</span></div>
                <p>La identidad digital de tu mascota. Registro, historial médico, carnet digital y beneficios en una sola plataforma.</p>
            </div>
            <div>
                <h4>Plataforma</h4>
                <ul>
                    <li><a href="/#como-funciona">Cómo funciona</a></li>
                    <li><a href="/#beneficios">Beneficios</a></li>
                    <li><a href="/registro">Registrar mascota</a></li>
                    <li><a href="/#marketplace">Marketplace</a></li>
                </ul>
            </div>
            <div>
                <h4>Aliados</h4>
                <ul>
                    <li><a href="/#veterinarias">Veterinarias</a></li>
                    <li><a href="/#empresas">Empresas</a></li>
                    <li><a href="/registro">Únete como aliado</a></li>
                </ul>
            </div>
            <div>
                <h4>Contacto</h4>
                <ul>
                    <li><a href="mailto:contacto@identipet.pe">contacto@identipet.pe</a></li>
                    <li><a href="/contacto">Formulario de contacto</a></li>
                    <li>Lima, Perú</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <span>© <?= date('Y') ?> IdentiPet. Todos los derechos reservados.</span>
            <span>Hecho con 🐾 en Perú · identipet.pe</span>
        </div>
    </div>
</footer>

</body>
</html>

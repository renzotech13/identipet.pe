<?php
/** @var string $content */
use App\Core\View;
$title = $title ?? 'IdentiPet';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= View::e($title) ?></title>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="icon" href="/assets/img/favicon.png">
</head>
<body>
<div class="auth-wrap">
    <aside class="auth-side">
        <a href="/" class="brand" style="color:#fff;margin-bottom:30px;">
            <span class="logo-dot">🐾</span>
            <span style="color:#fff">Identi<span style="color:#fff">Pet</span></span>
        </a>
        <h2>Todo sobre tu mascota, en un solo lugar.</h2>
        <p>Crea la identidad digital de tu mascota y accede a su historial, carnet, QR y beneficios exclusivos.</p>
        <ul>
            <li>✅ Carnet digital con código QR</li>
            <li>✅ Historial médico centralizado</li>
            <li>✅ Recordatorios de vacunas</li>
            <li>✅ Modo mascota perdida</li>
            <li>✅ Club de beneficios y descuentos</li>
        </ul>
    </aside>
    <div class="auth-main">
        <div class="auth-card">
            <?= $content ?>
        </div>
    </div>
</div>
</body>
</html>

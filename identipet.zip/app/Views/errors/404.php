<?php $title = 'Página no encontrada — IdentiPet'; ?>
<section class="section">
    <div class="container text-center" style="padding:80px 0">
        <div style="font-size:80px">🐾</div>
        <h1 style="font-size:48px;color:var(--color-secondary);margin:10px 0">404</h1>
        <p class="muted" style="font-size:18px">La página que buscas se fue a perseguir su cola. No la encontramos.</p>
        <a href="/" class="btn btn-primary btn-lg mt-2">Volver al inicio</a>
    </div>
</section>

<?php
use App\Core\View;
use App\Core\Csrf;
?>
<h1>Crear cuenta</h1>
<p class="sub">Regístrate para gestionar a tu mascota en IdentiPet.</p>

<form method="post" action="/registro">
    <?= Csrf::field() ?>
    <div class="form-row">
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="apellido">Apellido</label>
            <input type="text" id="apellido" name="apellido" class="form-control" required>
        </div>
    </div>
    <div class="form-group">
        <label for="email">Correo electrónico</label>
        <input type="email" id="email" name="email" class="form-control" required>
    </div>
    <div class="form-row">
        <div class="form-group">
            <label for="celular">Celular</label>
            <input type="tel" id="celular" name="celular" class="form-control">
        </div>
        <div class="form-group">
            <label for="password">Contraseña</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>
    </div>
    <div class="form-group">
        <label style="font-weight:400;font-size:13px">
            <input type="checkbox" name="terminos" required> Acepto los términos y condiciones y la política de privacidad.
        </label>
    </div>
    <button type="submit" class="btn btn-primary btn-block btn-lg">Crear cuenta</button>
</form>

<p class="text-center mt-3 muted">¿Ya tienes cuenta? <a href="/login">Inicia sesión</a></p>

<div class="alert alert-success mt-3" style="font-size:13px">
    Nota: el registro completo (validación, activación por correo, todos los campos) se implementa en el módulo de autenticación (siguiente paso).
</div>

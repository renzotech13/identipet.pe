<?php
use App\Core\View;
use App\Core\Csrf;
?>
<h1>Iniciar sesión</h1>
<p class="sub">Accede a tu cuenta IdentiPet.</p>

<form method="post" action="/login">
    <?= Csrf::field() ?>
    <div class="form-group">
        <label for="email">Correo electrónico</label>
        <input type="email" id="email" name="email" class="form-control" placeholder="tucorreo@ejemplo.com" required>
    </div>
    <div class="form-group">
        <label for="password">Contraseña</label>
        <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
    </div>
    <button type="submit" class="btn btn-primary btn-block btn-lg">Ingresar</button>
</form>

<p class="text-center mt-3 muted">¿No tienes cuenta? <a href="/registro">Regístrate aquí</a></p>

<div class="alert alert-success mt-3" style="font-size:13px">
    Nota: el procesamiento de inicio de sesión se activa en el módulo de autenticación (siguiente paso).
</div>

<?php
/** @var array $stats */
use App\Core\View;
?>

<!-- ===================== HERO ===================== -->
<section class="hero">
    <div class="container hero-grid">
        <div>
            <h1>La identidad digital de <span class="accent">tu mascota</span></h1>
            <p class="lead">Registra a tu mascota y accede a su historial médico, carnet digital, código QR y beneficios exclusivos. Todo en una sola plataforma.</p>
            <div class="hero-cta">
                <a href="/registro" class="btn btn-primary btn-lg">Registrar mi mascota</a>
                <a href="/#como-funciona" class="btn btn-outline btn-lg">Ver cómo funciona</a>
            </div>
            <div class="hero-badges">
                <span class="hero-badge"><span class="ico">🔒</span> Datos seguros</span>
                <span class="hero-badge"><span class="ico">📱</span> Carnet en tu celular</span>
                <span class="hero-badge"><span class="ico">🏥</span> Historial centralizado</span>
            </div>
        </div>
        <div class="hero-art">
            <div class="mock-card">
                <div class="mock-avatar">🐶</div>
                <div>
                    <h3>Max</h3>
                    <div class="code">IP-000123</div>
                    <div class="muted" style="font-size:14px">Labrador · 3 años</div>
                </div>
            </div>
            <div class="mock-qr"></div>
            <div class="text-center mt-2 muted" style="font-size:13px">Carnet digital IdentiPet con QR</div>
        </div>
    </div>
</section>

<!-- ===================== VIDEO INSTITUCIONAL ===================== -->
<section class="section">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Conoce IdentiPet</span>
            <h2>Un ecosistema digital para el cuidado de tu mascota</h2>
            <p>No compras un registro: compras tranquilidad, seguridad, organización y beneficios permanentes.</p>
        </div>
        <div style="max-width:860px;margin:0 auto;border-radius:18px;overflow:hidden;box-shadow:var(--shadow);aspect-ratio:16/9;background:#0d1430;display:flex;align-items:center;justify-content:center;color:#fff;">
            <div class="text-center">
                <div style="font-size:60px">▶</div>
                <p class="muted" style="color:#9aa8c2">Video institucional (próximamente)</p>
            </div>
        </div>
    </div>
</section>

<!-- ===================== BENEFICIOS ===================== -->
<section class="section alt" id="beneficios">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Beneficios</span>
            <h2>Todo lo que tu mascota necesita, centralizado</h2>
            <p>IdentiPet resuelve los problemas reales de cada propietario.</p>
        </div>
        <div class="cards">
            <div class="card"><div class="card-ico">🆔</div><h3>Identidad digital</h3><p>Un número único IdentiPet y una página pública para cada mascota.</p></div>
            <div class="card"><div class="card-ico">🏥</div><h3>Historial médico</h3><p>Vacunas, cirugías, medicamentos y exámenes siempre organizados.</p></div>
            <div class="card"><div class="card-ico">🔔</div><h3>Recordatorios</h3><p>Avisos de vacunas, desparasitaciones y controles por correo y WhatsApp.</p></div>
            <div class="card"><div class="card-ico">📇</div><h3>Carnet digital</h3><p>Llévalo en tu celular y compártelo con un código QR.</p></div>
            <div class="card"><div class="card-ico">📍</div><h3>Modo mascota perdida</h3><p>Activa una página de búsqueda con contacto y recompensa.</p></div>
            <div class="card"><div class="card-ico">🎁</div><h3>Club de beneficios</h3><p>Descuentos, cupones y cashback en comercios afiliados.</p></div>
        </div>
    </div>
</section>

<!-- ===================== CÓMO FUNCIONA ===================== -->
<section class="section" id="como-funciona">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Cómo funciona</span>
            <h2>Registra a tu mascota en 4 pasos</h2>
        </div>
        <div class="steps">
            <div class="step"><div class="num">1</div><h4>Crea tu cuenta</h4><p>Regístrate gratis en menos de 2 minutos.</p></div>
            <div class="step"><div class="num">2</div><h4>Registra tu mascota</h4><p>Agrega sus datos, foto y contactos de emergencia.</p></div>
            <div class="step"><div class="num">3</div><h4>Recibe su carnet</h4><p>Generamos su número único, QR y carnet digital.</p></div>
            <div class="step"><div class="num">4</div><h4>Gestiona todo</h4><p>Historial, recordatorios, documentos y beneficios.</p></div>
        </div>
    </div>
</section>

<!-- ===================== ESTADÍSTICAS ===================== -->
<section class="section alt">
    <div class="container">
        <div class="stats">
            <div class="stat"><div class="n"><?= (int) $stats['mascotas'] ?>+</div><div class="l">Mascotas registradas</div></div>
            <div class="stat"><div class="n"><?= (int) $stats['veterinarias'] ?>+</div><div class="l">Veterinarias afiliadas</div></div>
            <div class="stat"><div class="n"><?= (int) $stats['empresas'] ?>+</div><div class="l">Empresas aliadas</div></div>
            <div class="stat"><div class="n">24/7</div><div class="l">Acceso a la información</div></div>
        </div>
    </div>
</section>

<!-- ===================== MARKETPLACE ===================== -->
<section class="section" id="marketplace">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Marketplace</span>
            <h2>Todo para tu mascota, con descuentos de socio</h2>
            <p>Alimentos, accesorios, farmacia y más, próximamente en IdentiPet.</p>
        </div>
        <div class="cards">
            <div class="card"><div class="card-ico">🦴</div><h3>Alimentos y snacks</h3><p>Las mejores marcas con precios de socio.</p></div>
            <div class="card"><div class="card-ico">🦮</div><h3>Accesorios</h3><p>Collares, correas, arneses, placas y GPS.</p></div>
            <div class="card"><div class="card-ico">💊</div><h3>Farmacia</h3><p>Vitaminas y medicamentos OTC para tu mascota.</p></div>
        </div>
    </div>
</section>

<!-- ===================== VETERINARIAS / EMPRESAS ===================== -->
<section class="section alt" id="veterinarias">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Red de aliados</span>
            <h2>Veterinarias y empresas afiliadas</h2>
            <p>Un directorio con los mejores servicios para tu mascota, cerca de ti.</p>
        </div>
        <div class="cards" id="empresas">
            <div class="card"><div class="card-ico">🏥</div><h3>Veterinarias</h3><p>Encuentra clínicas y profesionales de confianza.</p></div>
            <div class="card"><div class="card-ico">🛍️</div><h3>Pet Shops</h3><p>Tiendas afiliadas con beneficios para socios.</p></div>
            <div class="card"><div class="card-ico">✂️</div><h3>Peluquerías y más</h3><p>Baño, peluquería, hoteles, guarderías y entrenadores.</p></div>
        </div>
        <div class="text-center mt-3">
            <a href="/registro" class="btn btn-accent btn-lg">Quiero afiliar mi empresa</a>
        </div>
    </div>
</section>

<!-- ===================== TESTIMONIOS ===================== -->
<section class="section">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Testimonios</span>
            <h2>Propietarios que ya confían en IdentiPet</h2>
        </div>
        <div class="cards">
            <div class="card"><p>"Por fin tengo el carnet y las vacunas de mi perrita en un solo lugar. Los recordatorios me salvan."</p><p class="mt-2"><strong>— María, Lima</strong></p></div>
            <div class="card"><p>"El modo mascota perdida me ayudó a recuperar a mi gato en un día. Increíble."</p><p class="mt-2"><strong>— Carlos, Arequipa</strong></p></div>
            <div class="card"><p>"Como veterinario, actualizar el historial de mis pacientes es ahora rapidísimo."</p><p class="mt-2"><strong>— Dr. Pérez</strong></p></div>
        </div>
    </div>
</section>

<!-- ===================== FAQ ===================== -->
<section class="section alt">
    <div class="container" style="max-width:820px">
        <div class="section-head">
            <span class="eyebrow">Preguntas frecuentes</span>
            <h2>Resolvemos tus dudas</h2>
        </div>
        <details class="faq-item"><summary>¿Cuánto cuesta registrar a mi mascota?</summary><p>El registro básico es gratuito. Tendremos planes premium con beneficios adicionales.</p></details>
        <details class="faq-item"><summary>¿Qué es el número IdentiPet?</summary><p>Es un identificador único y permanente para tu mascota, con su página pública y código QR.</p></details>
        <details class="faq-item"><summary>¿Puedo compartir el acceso con mi familia?</summary><p>Sí. El perfil familiar permite que varios miembros administren a la misma mascota.</p></details>
        <details class="faq-item"><summary>¿Funciona si mi mascota se pierde?</summary><p>Activas el modo mascota perdida y se genera una página de búsqueda con contacto, mapa y recompensa.</p></details>
    </div>
</section>

<!-- ===================== BLOG ===================== -->
<section class="section" id="blog">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Blog</span>
            <h2>Aprende a cuidar mejor a tu mascota</h2>
        </div>
        <div class="cards">
            <div class="card"><div class="card-ico">🩺</div><h3>Salud</h3><p>Consejos veterinarios y prevención.</p></div>
            <div class="card"><div class="card-ico">🥩</div><h3>Nutrición</h3><p>Alimentación según raza y edad.</p></div>
            <div class="card"><div class="card-ico">🎓</div><h3>Adiestramiento</h3><p>Guías de comportamiento y entrenamiento.</p></div>
        </div>
    </div>
</section>

<!-- ===================== CTA FINAL ===================== -->
<section class="section">
    <div class="container">
        <div class="cta-band">
            <h2>Dale a tu mascota su identidad digital hoy</h2>
            <p>Únete a IdentiPet y mantén toda su información segura y a la mano.</p>
            <a href="/registro" class="btn btn-light btn-lg">Crear mi cuenta gratis</a>
        </div>
    </div>
</section>

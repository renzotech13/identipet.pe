<?php use App\Core\Csrf; ?>
<section class="section">
    <div class="container" style="max-width:620px">
        <div class="section-head">
            <span class="eyebrow">Contacto</span>
            <h2>¿Tienes una consulta?</h2>
            <p>Escríbenos y te responderemos a la brevedad.</p>
        </div>
        <form method="post" action="/contacto">
            <?= Csrf::field() ?>
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="email">Correo</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="mensaje">Mensaje</label>
                <textarea id="mensaje" name="mensaje" class="form-control" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-lg btn-block">Enviar mensaje</button>
        </form>
        <p class="text-center muted mt-3">O escríbenos a <a href="mailto:contacto@identipet.pe">contacto@identipet.pe</a></p>
    </div>
</section>

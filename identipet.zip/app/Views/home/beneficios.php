<section class="section">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Beneficios</span>
            <h2>Por qué elegir IdentiPet</h2>
            <p>Un ecosistema digital pensado para el bienestar de tu mascota.</p>
        </div>
        <div class="cards">
            <div class="card"><div class="card-ico">🆔</div><h3>Identidad digital</h3><p>Número único y página pública por mascota.</p></div>
            <div class="card"><div class="card-ico">🏥</div><h3>Historial médico</h3><p>Vacunas, cirugías y exámenes organizados.</p></div>
            <div class="card"><div class="card-ico">🔔</div><h3>Recordatorios</h3><p>Avisos por correo y WhatsApp.</p></div>
            <div class="card"><div class="card-ico">📇</div><h3>Carnet digital</h3><p>En tu celular, con código QR.</p></div>
            <div class="card"><div class="card-ico">📍</div><h3>Modo perdida</h3><p>Página de búsqueda con contacto y recompensa.</p></div>
            <div class="card"><div class="card-ico">🎁</div><h3>Club de beneficios</h3><p>Descuentos, cupones y cashback.</p></div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container" style="max-width:820px">
        <div class="section-head">
            <span class="eyebrow">Cómo funciona</span>
            <h2>Registra y gestiona a tu mascota en minutos</h2>
            <p>IdentiPet centraliza toda la información de tu mascota en un solo lugar.</p>
        </div>
        <div class="steps">
            <div class="step"><div class="num">1</div><h4>Crea tu cuenta</h4><p>Regístrate gratis en menos de 2 minutos.</p></div>
            <div class="step"><div class="num">2</div><h4>Registra tu mascota</h4><p>Datos, foto y contactos de emergencia.</p></div>
            <div class="step"><div class="num">3</div><h4>Recibe su carnet</h4><p>Número único, QR y carnet digital.</p></div>
            <div class="step"><div class="num">4</div><h4>Gestiona todo</h4><p>Historial, recordatorios y beneficios.</p></div>
        </div>
        <div class="text-center mt-3"><a href="/registro" class="btn btn-primary btn-lg">Empezar ahora</a></div>
    </div>
</section>

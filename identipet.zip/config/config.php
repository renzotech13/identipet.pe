<?php
/**
 * IdentiPet - Configuración ACTIVA
 * ---------------------------------------------------------------------------
 * Edita los valores con los datos reales de tu base de datos en SiteGround.
 * (Esta es la copia que usa la aplicación; mantén config.sample.php como referencia.)
 * ---------------------------------------------------------------------------
 */

return [

    'app' => [
        'name'     => 'IdentiPet',
        'env'      => 'production',           // cambia a 'development' mientras pruebas
        'url'      => 'https://identipet.pe',
        'timezone' => 'America/Lima',
        'locale'   => 'es_PE',
        'key'      => 'CAMBIA-ESTA-CLAVE-POR-UNA-CADENA-LARGA-Y-ALEATORIA',
    ],

    'db' => [
        'host'     => 'localhost',
        'port'     => 3306,
        'database' => 'tu_basededatos',
        'username' => 'tu_usuario',
        'password' => 'tu_contraseña',
        'charset'  => 'utf8mb4',
        'prefix'   => '',
    ],

    'mail' => [
        'driver'     => 'mail',
        'host'       => 'smtp.identipet.pe',
        'port'       => 587,
        'username'   => 'no-reply@identipet.pe',
        'password'   => '',
        'encryption' => 'tls',
        'from_email' => 'no-reply@identipet.pe',
        'from_name'  => 'IdentiPet',
    ],

    'uploads' => [
        'path'        => STORAGE_PATH . '/uploads',
        'max_size'    => 10 * 1024 * 1024,
        'allowed_ext' => ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'mp4'],
    ],

    'session' => [
        'name'     => 'identipet_session',
        'lifetime' => 60 * 60 * 8,
    ],
];

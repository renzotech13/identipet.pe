<?php
/**
 * IdentiPet - Definición de rutas
 * ---------------------------------------------------------------------------
 * $router está disponible (instancia de App\Core\Router).
 * Firma: $router->get('/ruta', 'Controlador', 'metodo');
 *
 * A medida que construimos módulos (auth, mascotas, panel, marketplace...),
 * agregamos sus rutas aquí.
 * ---------------------------------------------------------------------------
 */

/** @var \App\Core\Router $router */

// ----- Público / Home -----
$router->get('/', 'HomeController', 'index');
$router->get('/como-funciona', 'HomeController', 'comoFunciona');
$router->get('/beneficios', 'HomeController', 'beneficios');
$router->get('/contacto', 'HomeController', 'contacto');

// Verificación de salud (útil para comprobar el despliegue)
$router->get('/health', 'HomeController', 'health');

// ----- Autenticación (módulo en construcción) -----
$router->get('/login', 'AuthController', 'showLogin');
$router->get('/registro', 'AuthController', 'showRegister');

// Las siguientes rutas se activarán al construir el módulo de autenticación:
// $router->post('/login', 'AuthController', 'login');
// $router->post('/registro', 'AuthController', 'register');
// $router->get('/logout', 'AuthController', 'logout');
// $router->get('/activar/{token}', 'AuthController', 'activate');

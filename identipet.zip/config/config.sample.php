<?php
/**
 * IdentiPet - Configuración (PLANTILLA)
 * ---------------------------------------------------------------------------
 * 1. Copia este archivo como "config.php" en la misma carpeta.
 * 2. Rellena los datos de tu base de datos de SiteGround y el dominio.
 * 3. NO subas config.php a un repositorio público (contiene credenciales).
 * ---------------------------------------------------------------------------
 */

return [

    // Datos generales de la aplicación
    'app' => [
        'name'     => 'IdentiPet',
        'env'      => 'production',          // 'development' o 'production'
        'url'      => 'https://identipet.pe', // sin barra final
        'timezone' => 'America/Lima',
        'locale'   => 'es_PE',
        // Clave secreta para tokens/CSRF. Genera una cadena larga y aleatoria.
        'key'      => 'CAMBIA-ESTA-CLAVE-POR-UNA-CADENA-LARGA-Y-ALEATORIA',
    ],

    // Conexión a la base de datos MySQL (datos del panel de SiteGround)
    'db' => [
        'host'     => 'localhost',
        'port'     => 3306,
        'database' => 'tu_basededatos',
        'username' => 'tu_usuario',
        'password' => 'tu_contraseña',
        'charset'  => 'utf8mb4',
        'prefix'   => '',
    ],

    // Configuración de correo (activación de cuenta, recordatorios)
    'mail' => [
        'driver'     => 'mail',              // 'mail' (PHP nativo) o 'smtp'
        'host'       => 'smtp.tu-dominio.pe',
        'port'       => 587,
        'username'   => 'no-reply@identipet.pe',
        'password'   => '',
        'encryption' => 'tls',
        'from_email' => 'no-reply@identipet.pe',
        'from_name'  => 'IdentiPet',
    ],

    // Subida de archivos (gestor documental)
    'uploads' => [
        'path'        => STORAGE_PATH . '/uploads',
        'max_size'    => 10 * 1024 * 1024,   // 10 MB
        'allowed_ext' => ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'mp4'],
    ],

    // Sesiones
    'session' => [
        'name'     => 'identipet_session',
        'lifetime' => 60 * 60 * 8,           // 8 horas
    ],
];

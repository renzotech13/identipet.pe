<?php
/**
 * IdentiPet - Front Controller
 * Punto de entrada único de la aplicación.
 * Todas las peticiones pasan por aquí (ver public/.htaccess).
 */

declare(strict_types=1);

define('IDENTIPET_START', microtime(true));

// Rutas base del proyecto
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');
define('PUBLIC_PATH', __DIR__);

// Cargar configuración
$config = require CONFIG_PATH . '/config.php';

// Reporte de errores según entorno
if (($config['app']['env'] ?? 'production') === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', STORAGE_PATH . '/logs/php-errors.log');
}

// Autoloader PSR-4 simple (sin Composer, ideal para hosting compartido)
spl_autoload_register(function (string $class): void {
    // App\Core\Router  ->  app/Core/Router.php
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = APP_PATH . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

use App\Core\App;

// Arrancar la aplicación
$app = new App($config);
$app->run();
